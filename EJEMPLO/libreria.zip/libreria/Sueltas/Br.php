<?php
/**
 * Clase que genera una etiqueta BR que sirve para crear un salto de linea
 */

class Br
{

    public function __toString()
    {
        return "<br/>\n";
    }

}